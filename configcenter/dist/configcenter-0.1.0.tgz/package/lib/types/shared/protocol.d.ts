export { apiFail, apiOk } from './api.js';
export type { ApiFail, ApiOk, ApiResult, WireErrorCode } from './api.js';
export declare const ROUTE_PREFIX = "/dsh-credential-center";
export declare const MAX_BODY_BYTES: number;
export declare const MAX_VALUE_LENGTH: number;
export declare const MAX_DESCRIPTION_LENGTH = 240;
/** One browser-safe row. Secret values never cross the read API. */
export interface VariableView {
    readonly name: string;
    readonly description: string;
    readonly configured: true;
    readonly updatedAt: string;
}
export interface VariableSnapshot {
    readonly revision: number;
    readonly variables: readonly VariableView[];
}
export interface SaveVariableInput {
    readonly name: string;
    readonly description: string;
    /** Omit while editing to keep the stored value unchanged. */
    readonly value?: string;
}
export declare function isVariableName(value: unknown): value is string;
export declare function validateSaveInput(value: unknown): SaveVariableInput;

/**
 * Shared browser transport for the configuration center.
 *
 * Every panel API goes through the same timeout, envelope unwrapping, and
 * typed error path, so a route failure is reported identically no matter
 * which feature produced it.
 */
import type { WireErrorCode } from '../shared/api.js';
/** A failed panel request: a wire error code or a transport failure. */
export declare class ApiClientError extends Error {
    readonly code: WireErrorCode | 'NETWORK';
    readonly reasonCode?: string | undefined;
    constructor(code: WireErrorCode | 'NETWORK', message: string, reasonCode?: string | undefined);
}
export declare const REQUEST_TIMEOUT_MS = 12000;
/** Minimal fetch shape; narrow enough to fake in tests, wide enough for `fetch`. */
export type FetchLike = (input: string, init?: {
    method?: string;
    headers?: Record<string, string>;
    body?: BodyInit | string;
    cache?: RequestCache;
}) => Promise<{
    status: number;
    json(): Promise<unknown>;
}>;
export declare function withTimeout<T>(request: Promise<T>, timeoutMs?: number): Promise<T>;
/** Decode a wire envelope, turning every failure shape into `ApiClientError`. */
export declare function unwrapJson<T>(response: {
    status: number;
    json(): Promise<unknown>;
}): Promise<T>;
/** Standard init for a JSON POST. */
export declare function jsonInit(value: unknown): {
    method: 'POST';
    headers: Record<string, string>;
    body: string;
};
/** Fetch with timeout; transport failures become `ApiClientError`. */
export declare function fetchJson(doFetch: FetchLike, input: string, init?: Parameters<FetchLike>[1]): Promise<{
    status: number;
    json(): Promise<unknown>;
}>;

import type { CredentialCenterApi } from './api.js';
import type { Translate } from './locales.js';
export interface CredentialPanelContainerProps {
    readonly api: CredentialCenterApi;
    readonly t: Translate;
}
/** Wires the credential state machine into the presentational panel. */
export declare function CredentialPanelContainer({ api, t }: CredentialPanelContainerProps): import("react/jsx-runtime").JSX.Element;

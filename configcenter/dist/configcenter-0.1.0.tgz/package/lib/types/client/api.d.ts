/** Browser API client for the credential routes. */
import { type SaveVariableInput, type VariableSnapshot } from '../shared/protocol.js';
import { type FetchLike } from './http.js';
export interface CredentialCenterApi {
    list(): Promise<VariableSnapshot>;
    save(input: SaveVariableInput): Promise<VariableSnapshot>;
    remove(name: string): Promise<VariableSnapshot>;
}
/** Create the same-origin browser API. */
export declare function createCredentialCenterApi(doFetch?: FetchLike): CredentialCenterApi;

/** Browser entry: locale, sidebar row, and the configuration-center panel. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "configcenter/client";
export declare const inject: string[];
export declare const PANEL_ID = "configuration-center";
export declare function apply(ctx: Context): void;

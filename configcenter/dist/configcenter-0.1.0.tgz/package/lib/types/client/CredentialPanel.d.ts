import type { Translate } from './locales.js';
import type { VariablePanelCommands, VariablePanelState } from './useVariables.js';
export interface CredentialPanelProps extends VariablePanelState, VariablePanelCommands {
    readonly t: Translate;
}
export declare function CredentialPanel(props: CredentialPanelProps): import("react/jsx-runtime").JSX.Element;

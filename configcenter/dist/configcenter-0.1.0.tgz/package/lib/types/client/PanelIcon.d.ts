/** Lock glyph for the sidebar row. */
export declare function PanelIcon(): import("react/jsx-runtime").JSX.Element;

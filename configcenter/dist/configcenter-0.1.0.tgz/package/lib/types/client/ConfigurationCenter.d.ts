import type { CredentialCenterApi } from './api.js';
import type { Translate } from './locales.js';
import type { InstallerApi } from '../tar-installer/client/api.js';
export interface ConfigurationCenterProps {
    readonly credentialsApi: CredentialCenterApi;
    readonly installerApi: InstallerApi;
    readonly t: Translate;
}
/** Top-level shell: one sidebar panel hosting the credential and plugin tabs. */
export declare function ConfigurationCenter({ credentialsApi, installerApi, t }: ConfigurationCenterProps): import("react/jsx-runtime").JSX.Element;

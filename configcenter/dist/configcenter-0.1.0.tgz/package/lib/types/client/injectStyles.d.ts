/** Idempotent, lifecycle-bound style injection shared by both panels. */
export declare function injectStylesOnce(id: string, css: string): () => void;

import type { SaveVariableInput, VariableSnapshot } from '../shared/protocol.js';
import type { CredentialCenterApi } from './api.js';
export type PanelPhase = 'loading' | 'ready' | 'error';
export interface VariablePanelState {
    readonly phase: PanelPhase;
    readonly snapshot: VariableSnapshot | null;
    readonly pending: boolean;
    readonly errorText: string | null;
}
export interface VariablePanelCommands {
    save(input: SaveVariableInput): Promise<boolean>;
    remove(name: string): Promise<boolean>;
    retry(): void;
}
export declare function useVariables(api: CredentialCenterApi): VariablePanelState & VariablePanelCommands;

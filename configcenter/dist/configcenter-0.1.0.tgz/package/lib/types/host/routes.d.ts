/** Same-origin JSON routes used by the credential-center page. */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { type ApiResult, type VariableSnapshot } from '../shared/protocol.js';
import { type VariableStore } from './store.js';
export interface ApiRequest {
    readonly method: string;
    readonly pathname: string;
    readonly body: unknown;
}
export interface ApiOutcome {
    readonly status: number;
    readonly body: ApiResult<VariableSnapshot>;
}
/** Map a parsed request onto the store. Pure so tests need no HTTP stack. */
export declare function dispatchApi(store: VariableStore, request: ApiRequest): Promise<ApiOutcome>;
/** Structural host surface this module needs; satisfied by a Cordis context. */
export interface CredentialRouteHost {
    readonly webServer: {
        register(route: {
            kind: 'prefix';
            path: string;
            handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
        }): () => void;
    };
    readonly logger?: {
        error(message: string): void;
    };
}
/** Register the panel routes and return their disposer. */
export declare function registerCredentialCenterRoutes(host: CredentialRouteHost, store: VariableStore): () => void;
/**
 * Fail-safe routes for a store that could not load: the panel gets a
 * structured 503 explaining the outage instead of an opaque 404.
 */
export declare function registerUnavailableRoutes(host: CredentialRouteHost, reason: string): () => void;

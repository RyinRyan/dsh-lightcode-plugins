import { type SaveVariableInput, type VariableSnapshot } from '../shared/protocol.js';
export interface VariableStoreOptions {
    readonly dataDir: string;
    readonly now?: () => number;
}
export declare class VariableStoreError extends Error {
    readonly code: 'VALIDATION' | 'NOT_FOUND';
    constructor(code: 'VALIDATION' | 'NOT_FOUND', message: string);
}
export declare class VariableStore {
    private readonly options;
    private readonly now;
    private document;
    private chain;
    private loaded;
    constructor(options: VariableStoreOptions);
    get documentPath(): string;
    load(): Promise<void>;
    snapshot(): VariableSnapshot;
    get(name: string): string | undefined;
    require(name: string): string;
    save(input: SaveVariableInput): Promise<VariableSnapshot>;
    remove(name: string): Promise<VariableSnapshot>;
    /** Wait for every queued mutation (used on dispose). */
    dispose(): Promise<void>;
    /** Serialize mutations through one promise chain, keeping failures isolated. */
    private mutate;
    private commit;
}
/** Storage directory; kept at the legacy location so existing variables carry over. */
export declare function defaultDataDir(): string;

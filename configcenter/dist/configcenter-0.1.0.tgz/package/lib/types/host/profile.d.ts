/**
 * Minimal structural view of Cordis' `profileContext` service. Kept
 * structural so this module never needs a hard dependency on the host types.
 */
export interface ProfileContextLike {
    readonly name?: unknown;
    readonly dir?: unknown;
}
/** Resolve `$DSH_HOME`, defaulting to `~/.dsh`. */
export declare function dshHome(): string;
/** Fallback profile directory when `profileContext.dir` is unavailable. */
export declare function defaultProfileDirectory(profile: string): string;
export declare function resolveProfileName(configured: string | undefined, profileContext: ProfileContextLike | undefined): string;
export declare function resolveProfileDirectory(profile: string, profileContext: ProfileContextLike | undefined): string;

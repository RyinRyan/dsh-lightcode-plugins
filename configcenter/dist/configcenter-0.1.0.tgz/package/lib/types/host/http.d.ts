/**
 * Same-origin JSON plumbing shared by the credential and installer routes.
 *
 * Host routes differ only in their domain logic; body framing, size limits,
 * origin checks, and response headers live here so the two route modules
 * cannot drift apart again.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
/** A request-body framing failure with its intended HTTP status. */
export declare class HttpBodyError extends Error {
    readonly status: 400 | 413;
    constructor(status: 400 | 413, message: string);
}
/**
 * Accept a same-origin request. Browsers always send an `origin` header on
 * cross-site POSTs, so a mismatched or missing host pairing is rejected;
 * non-browser clients that omit `origin` are allowed through.
 */
export declare function sameOrigin(request: Pick<IncomingMessage, 'headers'>): boolean;
/** Read at most `maxBytes` from the request stream. */
export declare function readBoundedBody(request: IncomingMessage, maxBytes: number): Promise<Buffer>;
/** Read a bounded JSON body; an empty body resolves to `undefined`. */
export declare function readJsonBody(request: IncomingMessage, maxBytes: number): Promise<unknown>;
/** Parse a JSON body from an already-bounded buffer; empty input resolves to `undefined`. */
export declare function parseJsonBody(bytes: Buffer): unknown;
export declare function sendJson(response: ServerResponse, status: number, body: unknown): void;

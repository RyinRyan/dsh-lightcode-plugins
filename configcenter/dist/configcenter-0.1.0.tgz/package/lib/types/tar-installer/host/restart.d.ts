import type { IncomingMessage } from 'node:http';
export interface RestartResult {
    readonly pid: number;
    readonly helperPid?: number;
    readonly logFile: string;
}
/** Stable reasons a restart may be refused; the browser translates these. */
export type RestartDisabledReason = 'restart-disabled' | 'debugger-active';
export declare function restartDisabledReason(allowRestart: boolean): RestartDisabledReason | null;
/** Restart is only for same-origin requests from the loopback interface. */
export declare function trustedRestartRequest(request: {
    readonly headers: IncomingMessage['headers'];
    readonly remoteAddress: string | undefined;
}): boolean;
/** Extract the serving port from the Host header, if it carries one. */
export declare function servingPort(request: {
    readonly headers: IncomingMessage['headers'];
}): number | null;
/**
 * Schedule the restart: write the helper, launch it detached, then terminate
 * this process so the port is released for the relaunch.
 */
export declare function scheduleRestart(port: number | null): RestartResult;

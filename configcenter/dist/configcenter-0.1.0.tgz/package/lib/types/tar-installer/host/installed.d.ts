import type { InstalledPackage } from '../shared/protocol.js';
export declare function listInstalledPackages(profileDirectory: string): InstalledPackage[];

import type { Activation } from '../shared/protocol.js';
interface PluginHandle {
    await(): Promise<unknown>;
    dispose(): Promise<unknown> | void;
}
/** Structural slice of a Cordis context; keeps this module free of hard dependencies. */
export interface HotContext {
    plugin(plugin: unknown, config: unknown): PluginHandle;
    logger?: {
        info?(message: string): void;
        warn?(message: string): void;
    };
}
interface Row {
    readonly id: string;
    readonly name: string;
}
/** Only plain insert patches can be faithfully represented in the live Include subtree. */
export declare function parseHotPatch(text: string): Row[] | null;
/** Mount a newly added package into this process. Durable activation stays owned by DSH's profile bundles. */
export declare function hotMount(ctx: HotContext, profileDirectory: string, packageName: string): Promise<Activation>;
/** Dispose a package this installer mounted into the current process. */
export declare function hotUnmount(packageName: string): Promise<boolean>;
/** Hot inputs are process-scoped; clear leftovers from a previous host before mounting. */
export declare function cleanHotInputs(profileDirectory: string): Promise<void>;
export {};

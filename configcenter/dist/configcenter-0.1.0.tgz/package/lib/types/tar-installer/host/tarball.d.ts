import type { PackagePreview } from '../shared/protocol.js';
export declare class TarballValidationError extends Error {
}
/** Inspect an npm-style gzipped tar without extracting it to disk. */
export declare function inspectTarball(bytes: Buffer, fileName: string, maxExpandedBytes?: number): Omit<PackagePreview, 'token'>;

import type { Activation, InstallOperation, InstalledPackage, InstallerSnapshot, PackagePreview } from '../shared/protocol.js';
import { StagingStore } from './staging.js';
export interface CommandResult {
    readonly exitCode: number | null;
    readonly timedOut: boolean;
    readonly output: string;
}
/** A rejected installer request carrying a stable, wire-facing error code. */
export declare class InstallerError extends Error {
    readonly code: 'VALIDATION' | 'BUSY';
    constructor(code: 'VALIDATION' | 'BUSY', message: string);
}
export type CommandRunner = (profile: string, tarballPath: string, allowScripts: boolean) => Promise<CommandResult>;
export type TarballPersister = (stagedPath: string, preview: PackagePreview) => Promise<string>;
export type Activator = (packageName: string) => Promise<Activation>;
export type RemoveRunner = (profile: string, packageName: string) => Promise<CommandResult>;
export type Deactivator = (packageName: string) => Promise<Activation>;
/** Metadata-only audit sink: never pass paths, archive contents, or credentials. */
export type InstallerAudit = (event: string, details: Record<string, string | boolean | number | null>) => void;
/** Install one tarball through DSH's own CLI, never a shell for user-controlled data. */
export declare function runDshInstall(profile: string, tarballPath: string, allowScripts: boolean): Promise<CommandResult>;
/** Remove exactly one direct profile dependency through DSH's own CLI. */
export declare function runDshRemove(profile: string, packageName: string): Promise<CommandResult>;
export interface InstallerServiceOptions {
    readonly profile: string;
    readonly allowInstallScripts: boolean;
    readonly maxUploadBytes: number;
    readonly profileDirectory?: string;
    readonly staging?: StagingStore;
    readonly run?: CommandRunner;
    readonly remove?: RemoveRunner;
    readonly readInstalled?: () => InstalledPackage[];
    readonly persist?: TarballPersister;
    readonly activate?: Activator;
    readonly deactivate?: Deactivator;
    readonly audit?: InstallerAudit;
}
export declare class InstallerService {
    #private;
    constructor(options: InstallerServiceOptions);
    snapshot(): InstallerSnapshot;
    isRunning(): boolean;
    inspect(bytes: Buffer, fileName: string): Promise<PackagePreview>;
    start(token: string, allowScripts: boolean): Promise<InstallOperation>;
    remove(packageName: string): Promise<InstallOperation>;
    dispose(): Promise<void>;
}

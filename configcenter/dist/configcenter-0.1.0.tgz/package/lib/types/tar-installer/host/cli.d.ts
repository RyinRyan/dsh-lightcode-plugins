/**
 * Absolute path of the DSH launcher (`bin.js` / `bin.ts` / the `dsh` shim),
 * or `undefined` when this host was not started through an identifiable one.
 */
export declare function dshLauncherPath(): string | undefined;
/** The Node binary to re-invoke, preferring the exact one running this host. */
export declare function nodeExecutable(): string;

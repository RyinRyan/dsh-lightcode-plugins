import type { PackagePreview } from '../shared/protocol.js';
export declare class StagingStore {
    #private;
    constructor(directory?: string, ttlMs?: number);
    /** Validate and persist one upload, returning its inspection preview. */
    stage(bytes: Buffer, fileName: string): Promise<PackagePreview>;
    /** Take ownership of a staged tarball, re-verifying it against its recorded digest. */
    consume(token: string): Promise<{
        path: string;
        preview: PackagePreview;
    } | null>;
    removePath(path: string): Promise<void>;
    cleanupExpired(): Promise<void>;
    dispose(): Promise<void>;
}

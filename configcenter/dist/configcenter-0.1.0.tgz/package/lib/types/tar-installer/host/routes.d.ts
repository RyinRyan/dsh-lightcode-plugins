/** Same-origin upload, install, remove, status, and restart API. */
import type { IncomingHttpHeaders, IncomingMessage, ServerResponse } from 'node:http';
import type { ApiResult } from '../../shared/api.js';
import { type InstallerService } from './installer.js';
/** Structural host surface; satisfied by a Cordis context. */
export interface WebServerHost {
    readonly webServer: {
        register(route: {
            kind: 'prefix';
            path: string;
            handler: (request: IncomingMessage, response: ServerResponse) => void | Promise<void>;
        }): () => void;
    };
    readonly logger?: {
        error(message: string): void;
    };
}
/** A parsed installer request, decoupled from node HTTP so tests need no server. */
export interface InstallerHttpRequest {
    readonly method: string;
    readonly pathname: string;
    readonly headers: IncomingHttpHeaders;
    readonly remoteAddress: string | undefined;
    /** Read the raw request body, enforcing `maxBytes`. */
    readBody(maxBytes: number): Promise<Buffer>;
}
export interface InstallerHttpResponse {
    readonly status: number;
    readonly body: ApiResult<unknown>;
}
export interface InstallerRouteOptions {
    readonly allowRestart: boolean;
    /** Injectable restart action for tests; defaults to the real self-restart. */
    readonly restart?: (port: number | null) => unknown;
    readonly logger?: {
        error(message: string): void;
    };
}
/** Maps one installer request to its outcome, one operation at a time. */
export declare class InstallerRouter {
    #private;
    private readonly service;
    private readonly options;
    constructor(service: InstallerService, options: InstallerRouteOptions);
    handle(request: InstallerHttpRequest): Promise<InstallerHttpResponse>;
}
/** Mount the same-origin upload, install, remove, status, and restart API. */
export declare function registerInstallerRoutes(host: WebServerHost, service: InstallerService, options: InstallerRouteOptions): () => void;

import type { PackagePreview } from '../shared/protocol.js';
/** Persist a tarball before pnpm records it as a file: dependency in the profile. */
export declare function persistTarball(profileDirectory: string, stagedPath: string, preview: PackagePreview): Promise<string>;

import type { InstallerApi } from './api.js';
import type { Translate } from '../../client/locales.js';
export interface InstallerPanelProps {
    readonly api: InstallerApi;
    readonly t: Translate;
}
export declare function InstallerPanel({ api, t }: InstallerPanelProps): import("react/jsx-runtime").JSX.Element;

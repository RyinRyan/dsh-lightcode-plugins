/** Browser API client for the installer routes. */
import { type InstallerSnapshot, type PackagePreview } from '../shared/protocol.js';
import { type FetchLike } from '../../client/http.js';
export interface InstallerApi {
    status(): Promise<InstallerSnapshot>;
    inspect(file: File): Promise<PackagePreview>;
    install(token: string, allowScripts: boolean): Promise<void>;
    restart(): Promise<void>;
    remove(name: string): Promise<void>;
}
/**
 * Create the same-origin browser API. Uploads stream the raw file body and
 * deliberately carry no request timeout; every other call is bounded.
 */
export declare function createInstallerApi(doFetch?: FetchLike): InstallerApi;

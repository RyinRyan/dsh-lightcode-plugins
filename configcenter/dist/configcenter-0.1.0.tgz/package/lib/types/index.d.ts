/** Host entry for the unified DSH configuration center. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Host-only service consumed by other DSH plugins. */
export interface CredentialVariables {
    /** Return the current value, or `undefined` when the variable is absent. */
    get(name: string): string | undefined;
    /** Return the current value or throw a descriptive error when absent. */
    require(name: string): string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Variables configured through the configuration center. */
        credentialVariables: CredentialVariables;
    }
}
export declare const name = "configcenter";
export declare const inject: string[];
export interface Config {
    /** Storage directory; defaults to `$DSH_HOME/dsh-credential-center` for compatibility. */
    dataDir?: string;
    profile?: string;
    maxUploadMiB?: number;
    allowInstallScripts?: boolean;
    allowRestart?: boolean;
}
export declare const Config: z<Config>;
/**
 * Mount the persistent store, the consumer service, and the browser routes.
 * Pure composition: discovery lives in `host/profile.ts`, storage in
 * `host/store.ts`, and the installer in `tar-installer/host/`.
 */
export declare function apply(ctx: Context, config: Config): void;

import type { FactorySource } from 'lightcode-factory-runtime/client';
import type { WorkflowRunView } from 'lightcode-factory-contracts/types';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface FactoryWebInjected {
    readonly hooks: {
        readonly factorySnapshot: FactorySource;
    };
    readonly refresh: () => Promise<void>;
    readonly loadMore: () => Promise<void>;
    readonly getRun: (runId: string) => Promise<WorkflowRunView>;
    readonly start: (workflowId: string, input?: Readonly<Record<string, string>>, scheduledFor?: string) => Promise<WorkflowRunView>;
    readonly cancel: (runId: string) => Promise<WorkflowRunView>;
    readonly review: (runId: string, decision: 'complete' | 'cancel') => Promise<WorkflowRunView>;
}
export type FactoryBoardProps = PropsRuntime<'main'> & PropsLocale<'factory'> & InjectFace<FactoryWebInjected>;
export declare function FactoryIcon({ size, active }: Pick<PropsRuntime<'sidebar.panellist'>, 'size' | 'active'>): import("react/jsx-runtime").JSX.Element;
export declare function FactoryBoard({ useFactorySnapshot, refresh, loadMore, getRun, start, cancel, review, t }: FactoryBoardProps): import("react/jsx-runtime").JSX.Element;

import type { WorkflowRunView } from 'lightcode-factory-contracts/types';
export declare function RunTrace({ run }: {
    run: WorkflowRunView;
}): import("react/jsx-runtime").JSX.Element;

import type { WorkflowRunView } from 'lightcode-factory-contracts/types';
import type { FactoryBoardProps } from './FactoryBoard.tsx';
export declare function RunOverview({ run, t }: {
    run: WorkflowRunView;
    t: FactoryBoardProps['t'];
}): import("react/jsx-runtime").JSX.Element;

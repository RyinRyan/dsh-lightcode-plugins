/** Browser plugin registrations for the workflow board. */
import type { Context } from '@deepseek-ai/cordis';
import type { ILightcodeFactoryClient } from 'lightcode-factory-runtime/client';
import { type FactoryWebInjected } from './FactoryBoard.tsx';
import { type FactoryLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        factory: FactoryLocaleKey;
    }
}
export declare const name = "lightcode-factory-web";
export declare const inject: string[];
/** Keep all command arguments intact when the slot adapts the browser client. */
export declare function createFactoryWebInjected(client: ILightcodeFactoryClient): FactoryWebInjected;
/** Register the board as a global panel once its target slots are declared. */
export declare function apply(ctx: Context): void;

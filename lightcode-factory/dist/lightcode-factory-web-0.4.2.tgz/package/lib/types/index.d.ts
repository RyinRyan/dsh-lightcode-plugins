/** Host plugin body; the feature is entirely browser-side. */
export declare function apply(): void;

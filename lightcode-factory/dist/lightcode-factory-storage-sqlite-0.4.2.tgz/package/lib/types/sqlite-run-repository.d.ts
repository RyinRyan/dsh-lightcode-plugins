import type { StoredWorkflowRun, StoredWorkflowRunPage, WorkflowRunQuery, WorkflowRunRepository } from 'lightcode-factory-contracts/repository';
import type { WorkflowRunView } from 'lightcode-factory-contracts/types';
/** SQLite infrastructure adapter for the Runtime-owned run repository port. */
export declare class SqliteWorkflowRunRepository implements WorkflowRunRepository {
    private readonly databasePath;
    private database?;
    constructor(databasePath: string);
    open(): Promise<void>;
    close(): void;
    listRuns(query: WorkflowRunQuery): Promise<StoredWorkflowRunPage>;
    listInterruptedRuns(): Promise<readonly StoredWorkflowRun[]>;
    getRun(runId: string): Promise<StoredWorkflowRun | undefined>;
    createRun(value: WorkflowRunView): Promise<StoredWorkflowRun>;
    saveRun(value: WorkflowRunView, expectedRevision: number): Promise<StoredWorkflowRun>;
    createBackup(destinationPath: string): Promise<void>;
    private get db();
    private transaction;
    private insertRun;
    private replaceNodes;
    private appendEvents;
    private readAggregate;
}

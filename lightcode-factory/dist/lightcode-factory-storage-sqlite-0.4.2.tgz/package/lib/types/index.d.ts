import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { StoredWorkflowRun, StoredWorkflowRunPage, WorkflowRunQuery, WorkflowRunRepository } from 'lightcode-factory-contracts/repository';
import type { WorkflowRunView } from 'lightcode-factory-contracts/types';
export interface Config {
    /** Local SQLite database file. Use a persistent local volume in production. */
    databasePath: string;
}
/** Cordis-owned lifecycle wrapper for the Factory run repository. */
export declare class LightcodeFactorySqliteStorage extends Service implements WorkflowRunRepository {
    private readonly config;
    static Config: z<Config>;
    private repository?;
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    listRuns(query: WorkflowRunQuery): Promise<StoredWorkflowRunPage>;
    listInterruptedRuns(): Promise<readonly StoredWorkflowRun[]>;
    getRun(runId: string): Promise<StoredWorkflowRun | undefined>;
    createRun(run: WorkflowRunView): Promise<StoredWorkflowRun>;
    saveRun(run: WorkflowRunView, expectedRevision: number): Promise<StoredWorkflowRun>;
    createBackup(destinationPath: string): Promise<void>;
    private get value();
}
export { SqliteWorkflowRunRepository } from './sqlite-run-repository.ts';
export default LightcodeFactorySqliteStorage;

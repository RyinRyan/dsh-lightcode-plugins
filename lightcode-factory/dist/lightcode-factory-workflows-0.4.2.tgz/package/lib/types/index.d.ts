/** Built-in Workflow Catalog. Each workflow keeps its implementation in a workflow-id directory. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type MorningScriptDemoConfig } from './catalog/morning-script-demo/index.ts';
export interface Config extends MorningScriptDemoConfig {
    /** Register the model-and-subprocess demo when its host capabilities are available. */
    demoEnabled?: boolean;
}
export declare const Config: z<Config>;
export declare const name = "lightcode-factory-workflows";
export declare const inject: string[];
export declare function apply(ctx: Context, config: Config): void;
export { releaseReadinessWorkflow } from './catalog/release-readiness/index.ts';
export { createMorningScriptDemoWorkflow } from './catalog/morning-script-demo/index.ts';
declare const _default: {
    name: string;
    inject: string[];
    Config: z<Config>;
    apply: typeof apply;
};
export default _default;

/** Deterministic release-readiness workflow used to validate Factory extension contracts. */
import type { WorkflowRegistration } from 'lightcode-factory-contracts/workflow';
export declare const releaseReadinessWorkflow: WorkflowRegistration;

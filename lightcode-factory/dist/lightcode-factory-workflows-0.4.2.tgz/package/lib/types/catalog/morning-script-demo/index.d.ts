import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { WorkflowRegistration } from 'lightcode-factory-contracts/workflow';
/** Business execution limits owned by this workflow, not by the Runtime. */
export interface MorningScriptDemoConfig {
    /** Parent directory containing one artifact directory per task. */
    artifactRoot: string;
    /** Maximum bytes retained from the generated process output. */
    outputLimitBytes?: number;
    /** Maximum accumulated model stream characters before aborting. */
    modelOutputLimitChars?: number;
    /** Independent timeout for model generation and script execution. */
    timeoutMs?: number;
}
export declare const morningScriptDemoConfig: z<MorningScriptDemoConfig>;
/** Register the workflow for this plugin's lifetime.
 * @param ctx - injected DSH capabilities.
 * @param config - validated workflow configuration.
 */
export declare function createMorningScriptDemoWorkflow(ctx: Context, config: MorningScriptDemoConfig): WorkflowRegistration;

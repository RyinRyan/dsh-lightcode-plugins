import { z } from 'zod';
import type { WorkflowRunView } from './types.ts';
/** Runtime schema for one persisted workflow run. */
export declare const workflowRunSchema: z.ZodObject<{
    id: z.ZodString;
    workflowId: z.ZodString;
    name: z.ZodString;
    workflowVersion: z.ZodString;
    input: z.ZodRecord<z.ZodString, z.ZodString>;
    status: z.ZodEnum<{
        queued: "queued";
        running: "running";
        review: "review";
        completed: "completed";
        cancelled: "cancelled";
        failed: "failed";
    }>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    scheduledFor: z.ZodOptional<z.ZodString>;
    currentNodeId: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    nodes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            completed: "completed";
            cancelled: "cancelled";
            failed: "failed";
            pending: "pending";
        }>;
        observations: z.ZodDefault<z.ZodArray<z.ZodObject<{
            at: z.ZodString;
            kind: z.ZodString;
            title: z.ZodString;
            detail: z.ZodString;
            callId: z.ZodOptional<z.ZodString>;
            sessionId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        startedAt: z.ZodOptional<z.ZodString>;
        finishedAt: z.ZodOptional<z.ZodString>;
        output: z.ZodOptional<z.ZodJSONSchema>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    events: z.ZodArray<z.ZodObject<{
        sequence: z.ZodNumber;
        at: z.ZodString;
        type: z.ZodString;
        message: z.ZodString;
        nodeId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Parse one authoritative persisted aggregate at storage and migration boundaries. */
export declare function parseWorkflowRun(value: unknown): WorkflowRunView;

import type { RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkflowDefinition, WorkflowReviewRequest, WorkflowRunListRequest, WorkflowRunPage, WorkflowRunRequest, WorkflowRunView, WorkflowStartRequest } from './types.ts';
export interface FactoryRemote {
    catalog(): Promise<RemoteResult<readonly WorkflowDefinition[]>>;
    listRuns(request: WorkflowRunListRequest): Promise<RemoteResult<WorkflowRunPage>>;
    getRun(request: WorkflowRunRequest): Promise<RemoteResult<WorkflowRunView>>;
    start(request: WorkflowStartRequest): Promise<RemoteResult<WorkflowRunView>>;
    cancel(request: WorkflowRunRequest): Promise<RemoteResult<WorkflowRunView>>;
    review(request: WorkflowReviewRequest): Promise<RemoteResult<WorkflowRunView>>;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteNamespaceMap {
        factory: FactoryRemote;
    }
}
export declare const factoryRemote: TypertRemoteContribution;
export default factoryRemote;

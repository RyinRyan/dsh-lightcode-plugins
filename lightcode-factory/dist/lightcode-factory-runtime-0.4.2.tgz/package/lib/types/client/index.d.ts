/** Browser-side bounded projection and command facade. */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkflowDefinition, WorkflowRunView } from 'lightcode-factory-contracts/types';
export interface FactoryClientSnapshot {
    readonly definitions: readonly WorkflowDefinition[];
    readonly runs: readonly WorkflowRunView[];
    readonly nextCursor?: string;
    readonly phase: 'loading' | 'ready' | 'error';
    readonly error: string | null;
    readonly loadingMore: boolean;
}
export interface FactorySource {
    getSnapshot(): FactoryClientSnapshot;
    subscribe(listener: () => void): () => void;
}
export interface ILightcodeFactoryClient {
    readonly state: FactorySource;
    refresh(): Promise<void>;
    loadMore(): Promise<void>;
    getRun(runId: string): Promise<WorkflowRunView>;
    start(workflowId: string, input?: Readonly<Record<string, string>>, scheduledFor?: string): Promise<WorkflowRunView>;
    cancel(runId: string): Promise<WorkflowRunView>;
    review(runId: string, decision: 'complete' | 'cancel'): Promise<WorkflowRunView>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        lightcodeFactoryClient: ILightcodeFactoryClient;
    }
}
type RemoteFactory = TypertClientRemote['factory'];
export declare class LightcodeFactoryClient extends Service implements ILightcodeFactoryClient, FactorySource {
    private readonly remote;
    readonly state: FactorySource;
    private value;
    private readonly listeners;
    constructor(ctx: Context, remote: RemoteFactory);
    getSnapshot(): FactoryClientSnapshot;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<void>;
    loadMore(): Promise<void>;
    getRun(runId: string): Promise<WorkflowRunView>;
    start(workflowId: string, input?: Readonly<Record<string, string>>, scheduledFor?: string): Promise<WorkflowRunView>;
    cancel(runId: string): Promise<WorkflowRunView>;
    review(runId: string, decision: 'complete' | 'cancel'): Promise<WorkflowRunView>;
    private command;
    private upsert;
    private notify;
}
export declare const name = "lightcode-factory-runtime-client";
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<void>;
export {};

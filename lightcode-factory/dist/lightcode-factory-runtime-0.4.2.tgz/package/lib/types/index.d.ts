import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkflowRegistration } from 'lightcode-factory-contracts/workflow';
import type { WorkflowDefinition, WorkflowStartRequest, WorkflowRunRequest, WorkflowReviewRequest, WorkflowRunListRequest, WorkflowRunPage, WorkflowRunView } from 'lightcode-factory-contracts/types';
/** Deployment choices for the durable workflow runtime. */
export interface Config {
    /** Maximum number of workflow runs executing simultaneously. */
    maxConcurrentRuns?: number;
    /** Maximum serialized node output size. */
    maxOutputBytes?: number;
    /** Maximum durable execution facts retained for each workflow node. */
    maxNodeObservations?: number;
    /** Maximum characters retained in one execution fact. */
    maxObservationChars?: number;
}
/** Host service for durable tasks and complete workflow registrations. */
export declare class LightcodeFactoryRuntime extends TypertRemoteService {
    static inject: string[];
    static Config: z<Config>;
    private readonly definitions;
    private readonly accepted;
    private readonly tasks;
    private readonly admissions;
    private readonly mutations;
    private stopped;
    private readonly subscribers;
    private readonly controllers;
    private readonly queuedIds;
    private readonly scheduledTimers;
    private readonly recoverableScheduled;
    private activeCount;
    private pumping;
    private readonly config;
    constructor(ctx: Context, config: Config);
    /** Register the wire contract and reconcile runs that survived a host restart. */
    protected [Service.init](): Promise<void>;
    private get repository();
    /** Register a complete workflow; disposal cancels and drains its tasks.
     * @param registration - metadata and execution callback.
     * @returns disposer owned by the registering plugin.
     */
    registerWorkflow(registration: WorkflowRegistration): () => Promise<void>;
    private metadata;
    private recoverScheduledRuns;
    /** Read the installed workflow catalog. */
    catalog(): Promise<readonly WorkflowDefinition[]>;
    /** Read one bounded page of durable runs. */
    listRuns(request?: WorkflowRunListRequest): Promise<WorkflowRunPage>;
    /** Read the latest aggregate for a detail view. */
    getRun(request: WorkflowRunRequest): Promise<WorkflowRunView>;
    /** Subscribe to durable task writes.
     * @param listener - synchronous observer; exceptions are logged and contained.
     * @returns Function removing the observer.
     */
    subscribe(listener: () => void): () => void;
    /** Queue one registered workflow.
     * @param request - workflow identifier and declared text inputs.
     * @returns Persisted task; cancelled if its plugin unloads during admission.
     */
    start(request: WorkflowStartRequest): Promise<WorkflowRunView>;
    private queueRun;
    /** Cancel a task before notifying its workflow's AbortSignal.
     * @param request - identifier of a queued, running or review-pending task.
     * @returns Persisted cancellation; rejects for other terminal states.
     */
    cancel(request: WorkflowRunRequest): Promise<WorkflowRunView>;
    private cancelFrom;
    /** Apply the final human decision.
     * @param request - review-pending task identifier and decision.
     * @returns Persisted terminal task; rejects unless awaiting review.
     */
    review(request: WorkflowReviewRequest): Promise<WorkflowRunView>;
    private normalizeScheduledFor;
    private enqueueRun;
    private armScheduledRun;
    private releaseScheduledRun;
    private clearScheduledTimer;
    private removeQueuedId;
    private pump;
    private drainQueue;
    private execute;
    private executeNode;
    private assertRunning;
    private update;
    private appendEvent;
    private reportObservation;
    private clearCurrentNode;
    private requireRun;
    private save;
    private publish;
    private now;
    private assertAcceptingTasks;
    private encodeCursor;
    private decodeCursor;
}
export default LightcodeFactoryRuntime;
